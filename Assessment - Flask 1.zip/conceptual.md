### Conceptual Exercise

Answer the following questions below:

- What are important differences between Python and JavaScript?
 >**Server-side scripting vs. Client-side scripting.**

- Given a dictionary like ``{"a": 1, "b": 2}``: , list two ways you
  can try to get a missing key (like "c") *without* your programming
  crashing.
> **using get()**

- What is a unit test? 

  > **test one unit of functionality. does not test  framework itself.** 

- What is an integration test?

 > **test that components work together** 

- What is the role of web application framework, like Flask?

 > **Handle GET and POST request and issue responses via HTTP.**
 
- You can pass information to Flask either as a parameter in a route URL
  (like '/foods/pretzel') or using a URL query param (like
  'foods?type=pretzel'). How might you choose which one is a better fit
  for an application?

 > **depending on the usecase. a URL query is best for functions like searchs**

- How do you collect data from a URL placeholder parameter using Flask?

 > **specify the variable in the app.route. use that variable as a paramater in the routing function.**

- How do you collect data from the query string using Flask?
 > **request.args dictionary**

- How do you collect data from the body of the request using Flask?
> **request.form dictionary**

- What is a cookie and what kinds of things are they commonly used for?
 >**Cookies are text files with small pieces of data **

- What is the session object in Flask?
 >**used to track the session data that contains a key-value pair of the session variables and values.**

- What does Flask's `jsonify()` do? 
 >**jsonify will take JSON serializeable data in python and convert it to a JSON string.**