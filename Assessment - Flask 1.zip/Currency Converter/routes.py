from flask import Flask, requests, render_template, redirect, flash, session


app = Flask(__name__)
app.config['SECRET_KEY'] = 'dadjahgdjagjdgsjkt63827fbg'

@app.route('/', methods=['GET', 'POST'])
def home():
    forms = InputDataForms()
    if forms.validate_on_submit():
        date = forms.date.data
        base = forms.base.data
        currency = forms.currency.data
        quantity = forms.quantity.data
        
        base_url = 'https://ratesapi.io/'
        url = base_url + '?base=' + base + '&symbols=' + currency
        response = requests.get(url)
        if (response.ok is False):
            flash(f'Error: {response.status_code}')
            flash(f"{response.json()['error']}")
        else:
            data = response.json()
            total = quantity*data['rates'][currency]
            flash("{} {} = {:.2f} {} Day of {}".format(quantity, base, total, currency, date))

    return render_template('home.html', form=forms)